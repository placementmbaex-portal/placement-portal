# Handoff: MBAEx Placement Portal — mobile-first UI overhaul

## Overview

The IIM Calcutta MBAEx Placement Portal (`placementmbaex-portal/placement-portal`, branch `master`) is a working Next.js 16 + Supabase app. The data model, auth, server actions and business logic are all in place and are **not** part of this work. What is missing is the front end: there is no bottom navigation, no logo anywhere, and the admin, login and profile pages are still stock Tailwind `zinc` while student pages already follow `DESIGN.md`.

This handoff redesigns the whole front end as a **mobile-first app**:

- The **student** side is a five-tab app locked to a 390px column at every viewport. On a laptop the column stays a column, centred on the IIM Calcutta brown.
- The **admin** side is the only place the layout goes wide: a brown top bar with tabs, and dense tables.

## About the design files

`MBAEx Placement Portal.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing intended look, structure and behaviour. It is not production code to copy. Open it in a browser: it is one canvas holding 22 screens. `support.js` and `assets/logo-iimc.svg` are needed for it to render.

The task is to **recreate these designs inside the existing Next.js repo**, using its established patterns: App Router server components, server actions, Tailwind v4 with the `@theme inline` tokens already defined in `src/app/globals.css`, and `next/font` for typography. Do not introduce a component library, a CSS-in-JS runtime, or a state manager. The prototype uses inline styles only because of the tool it was authored in; in the repo, use Tailwind utility classes against the existing tokens.

## Fidelity

**High-fidelity.** Every colour, font size, line-height, radius, border and spacing value in the prototype is deliberate and listed below. Recreate the UI pixel-perfectly. Where the prototype and this README disagree, this README wins.

## Screen index

Each screen in the prototype carries a visible id badge. Use it to cross-reference.

| id | Screen | Target route / file |
| --- | --- | --- |
| 1a–1d | **Recreation of the current UI.** Baseline only — this is what exists today, for before/after comparison. Do not build these. | — |
| 2a | Home, urgency-first (**build this one**) | `src/app/(app)/page.tsx` |
| 2b | Home, digest alternative (reference for the dark header only) | — |
| 2c | Announcements | new `src/app/(app)/announcements/page.tsx` |
| 2d | Open roles | new `src/app/(app)/jobs/page.tsx` |
| 2e | Role detail + apply sheet | `src/app/(app)/jobs/[id]/page.tsx`, `apply-dialog.tsx` |
| 2f | Profile & CVs | `src/app/(app)/profile/page.tsx`, `cv-upload-form.tsx`, `profile-form.tsx` |
| 2g | Calendar | `src/app/(app)/calendar/page.tsx` |
| 2h | My applications | new `src/app/(app)/applications/page.tsx` |
| 2i | Bottom nav treatments A/B/C + sign-in | new `src/components/bottom-nav.tsx`, `src/app/login/page.tsx` |
| 2j | Admin dashboard, adoption-first (**build this one**) | `src/app/(app)/admin/page.tsx` |
| 2k | Admin dashboard, funnel alternative (build the "Not seen in 7+ days" list from it — see below) | — |
| 2l | Admin jobs table | `src/app/(app)/admin/jobs/page.tsx` |
| 2m | Delete a role | new `src/app/(app)/admin/jobs/[id]/delete/page.tsx` or a dialog |
| 2n | Applicants | `src/app/(app)/admin/jobs/[id]/applicants/page.tsx` |
| 2o | Announcement moderation queue | `src/app/(app)/admin/announcements/page.tsx` |
| 2p | Students with last-active | new `src/app/(app)/admin/students/page.tsx` |
| 2q | Create-a-role, add-a-company, add-an-event forms | `admin/jobs/job-form.tsx`, `admin/companies/company-form.tsx`, `admin/events/event-form.tsx` |
| 2r | Desktop lock — the student column on brown | `src/app/(app)/layout.tsx` |

**Decisions already made, do not re-litigate:** Home is 2a. Admin dashboard is 2j, plus 2k's "Not seen in 7+ days" list added as a panel. Bottom nav is treatment **A** (icon + label, navy active). The MBAEx mark is set in type, not an image.

---

## Design tokens

Every token below already exists in `src/app/globals.css` unless marked NEW. Add the new ones to both `:root` and the `@theme inline` block so they become Tailwind utilities.

### Colour

| Token | Hex | Use |
| --- | --- | --- |
| `--navy` | `#014488` | primary buttons, links, active tab, pinned rule |
| `--flame` | `#FB5813` | 3px deadline rule, urgency dot, `Ex` in the wordmark. **Never text.** |
| `--brown` | `#592B0B` | admin top bar, desktop backdrop behind the student column |
| `--ink` | `#0B2545` | all body text and headings; the dark header in 2b |
| `--closing` | `#B03604` | countdown text under 48h, destructive text links, error text |
| `--slate` | `#5A6675` | secondary text, metadata, form labels |
| `--rule` | `#DEE3E8` | borders, dividers, 1px table rules |
| `--paper` | `#FAFAF8` | page background, table header fill, logo chip |
| `--surface` | `#FFFFFF` | cards, sticky header, bottom nav |
| `--live` | `#0F7B54` | deadline > 48h, "Applied ✓", healthy adoption |
| `--shut` | `#8B94A3` | closed / past / inactive tab icons |
| `--scroll` | `#F4F5F7` | NEW — the scrolling list ground behind cards |

### Category chip colours (NEW)

Chips are `border-radius: 5px`, `padding: 4px 7px`, `font-weight: 700`, `10px`, `letter-spacing: .07em`, `text-transform: uppercase`.

| Category | Background | Text |
| --- | --- | --- |
| Pre-placement talk | `#E7EEF6` | `#014488` |
| Shortlist / result | `#E4F1EC` | `#0C6B49` |
| Deadline change | `#FDEAE0` | `#B03604` |
| Process / logistics | `#F2EAE4` | `#5C3111` |
| General notice | `#ECEFF3` | `#4C5866` |
| Pinned (not a category — an additional chip) | `#E7EEF6` | `#014488` |

Application-status chips reuse these: Applied → Pre-placement-talk colours, Shortlisted / Offer → Shortlist colours, In process / Not selected → General-notice colours.

### Type

Already wired via `next/font` in `src/app/layout.tsx`. Add the weights marked NEW to the `IBM_Plex_Sans` call.

- **Source Serif 4**, weight 600 → `--font-display`. Page titles, section headings, company and role names.
- **IBM Plex Sans**, weights 400, 500, **600 (NEW)**, **700 (NEW)** → `--font-body`. Everything else.

| Role | Size / line-height | Family | Weight |
| --- | --- | --- | --- |
| Screen title (phone) | 26 / 1.2 | display | 600 |
| Page title (admin) | 28 / 1.2 | display | 600 |
| Section heading | 17–19 / 1.3 | display | 600 |
| Card title / company name | 16–17 / 1.35 | display | 600 |
| Body | 14–15 / 1.55 | body | 400 |
| Metadata | 12–13.5 / 1.45 | body | 400 |
| Countdown, counts, table numbers | 12.5–13.5 / 1.4 | body | 500, `tabular-nums` |
| Eyebrow above a title | 10.5 | body | 600, `letter-spacing: .1em`, uppercase |
| Chip | 10 | body | 700, `letter-spacing: .07em`, uppercase |
| Tab label | 10.5 | body | 600 |
| Big stat | 34–44 / 1 | body | 600, `tabular-nums` |

`DESIGN.md` currently forbids uppercase eyebrows. That rule is **overridden** for this work — the eyebrow is now part of the screen-title block. Update `DESIGN.md` to match rather than leaving the two in conflict.

### Spacing, radius, shadow

- Spacing base 4px: `4 8 10 12 14 16 18 20 22 24 26 32`.
- Radius: **14px** on phone cards, **12px** on admin panels, **10px** on inner list rows, **8px** on buttons and the logo chip, **6px** on admin inputs/buttons/menus, **999px** on pills and avatars, **30px** on the phone frame, **20px 20px 0 0** on a bottom sheet.
- Shadow: exactly one, `0 1px 3px rgba(22,32,46,.08)`, on raised cards, dialogs and dropdowns. The bottom sheet gets `0 -4px 24px rgba(11,37,69,.2)`. Nothing else.
- Touch targets: 44px minimum on every tappable element in the student app. Tab bar items, icon buttons and list-row actions all meet this.

---

## The frame

### Student shell — `src/app/(app)/layout.tsx`

Replace the current `<Header /> + flex column` with a hard 390px lock:

- Outer: `min-height: 100dvh`, `background: var(--brown)`, `display: flex`, `flex-direction: column`, `align-items: center`.
- Above the column at `≥ 768px` only: a 30px-top brand lockup — the IIMC seal on a paper chip, a 1px `rgba(255,255,255,.28)` divider, `MBAEx` in white with `Ex` in flame at 17px/700, then `Placements` at 13px/400 `letter-spacing: .16em` uppercase in `rgba(255,255,255,.6)`. Hidden below 768px.
- The column: `width: 390px; max-width: 100%`, `background: var(--paper)`, `flex: 1`, `border-radius: 20px 20px 0 0` and `box-shadow: 0 -2px 40px rgba(0,0,0,.28)` at `≥ 768px`; both removed below 768px so it is edge-to-edge on a phone.
- Inside the column: sticky brand header, scrolling content, sticky bottom nav.

This is screen **2r**.

### Student brand header — rewrite `src/components/header.tsx`

56px, `background: var(--surface)`, `border-bottom: 1px solid var(--rule)`, `padding: 10px 20px`, `position: sticky; top: 0`, `display: flex; align-items: center; gap: 12px`.

1. IIMC seal — `<Image src="/logo-iimc.svg" width={28} height={28} alt="IIM Calcutta" />`, `object-fit: contain`.
2. 1px × 22px `var(--rule)` divider.
3. Wordmark: `<span class="font-body text-[17px] font-bold tracking-[-.01em] text-navy">MBA<span class="text-flame">Ex</span></span>`.
4. Spacer.
5. Avatar → `/profile`: 34px circle, `background: var(--navy)`, white initials at 12.5px/600, from `student.name`.

Nothing else. The current header's inline `Profile / Calendar / Admin / Pending / Sign out` links all move — Profile and Calendar to the tab bar, Admin and Sign out into the profile screen.

**Never tint or filter the seal.** On the brown admin bar and any dark header, place the untinted seal at 30px on a 36px `var(--paper)` chip with `border-radius: 8px`. Only the MBAEx wordmark reverses to white. The seal has fine gear teeth and lettering that a `brightness(0) invert(1)` filter destroys. Never render it below 24px.

### Bottom nav — new `src/components/bottom-nav.tsx`

Client component; `usePathname()` decides the active tab. `position: sticky; bottom: 0`, `background: var(--surface)`, `border-top: 1px solid var(--rule)`, `padding: 8px 0 14px` (the extra bottom padding is the iOS home-indicator margin — use `env(safe-area-inset-bottom)` if you prefer), `display: grid; grid-template-columns: repeat(5, 1fr)`.

Each tab: `<Link>`, `flex-direction: column`, `gap: 4px`, `min-height: 44px`, 22px icon at `stroke-width: 1.9`, `stroke-linecap`/`linejoin: round`, `fill: none`, `stroke: currentColor`; label 10.5px/600. Active `color: var(--navy)`; inactive `color: var(--shut)`.

| Tab | Label | Route | Icon path (24×24 viewBox) |
| --- | --- | --- | --- |
| 1 | Home | `/` | `M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H10v6H4a1 1 0 0 1-1-1z` |
| 2 | Notices | `/announcements` | `M18 15V10a6 6 0 0 0-12 0v5l-2 3h16z` + `M10 21h4` |
| 3 | Roles | `/jobs` | `<rect x="3" y="7" width="18" height="13" rx="2"/>` + `M9 7V5h6v2` |
| 4 | Calendar | `/calendar` | `<rect x="3" y="5" width="18" height="16" rx="2"/>` + `M3 10h18M8 3v4M16 3v4` |
| 5 | Profile | `/profile` | `<circle cx="12" cy="8" r="4"/>` + `M4 21c0-4 3.6-6 8-6s8 2 8 6` |

Put an unread dot on Notices when there is an approved announcement newer than the user's last visit: 8px flame circle with a 1.5px white ring, top-right of the icon. That needs a `last_notices_seen_at` column, or you can skip the dot in v1.

### Admin shell — new `src/app/(app)/admin/layout.tsx`

Full width, no 390px lock. Brown top bar in two rows, `padding: 0 24px`:

- **Row 1**, 58px: seal on a paper chip, divider, `MBAEx` wordmark in white with flame `Ex` at 16px/700, `Placements admin` at 13.5px/400 in `rgba(255,255,255,.7)`, spacer, a `3 pending approvals` capsule (`height: 32px`, `border-radius: 8px`, `background: rgba(255,255,255,.14)`, 12.5px/500 white) linking to the moderation queue, then a 32px avatar circle in `rgba(255,255,255,.18)` with a `rgba(255,255,255,.3)` border.
- **Row 2**, 40px tabs: Overview · Jobs · Companies · Students · Announcements · Events. `padding: 0 14px`, 13px. Active: white, 600, `border-bottom: 2px solid var(--flame)`. Inactive: `rgba(255,255,255,.72)`, 500, transparent bottom border. The Announcements tab carries a flame count badge — 17px min-width pill, 10px/700 white.

Page body: `background: var(--paper)`, `padding: 26px 24px 30px`.

---

## Screens

Common phone-screen anatomy, top to bottom: brand header → screen-title block (`padding: 20px 20px 0`; eyebrow then 26px serif title) → content on `var(--scroll)` where the content is a card list, or on `var(--paper)` where it is form-like → bottom nav pinned by `margin-top: auto`.

### 2a — Home · `/`

Data already fetched in `page.tsx`; keep the queries, add nothing.

1. **Greeting block.** Eyebrow `Placements · MBAEx 2026`; title `Good morning, {firstName}` (morning/afternoon/evening by IST hour).
2. **Urgent deadline band.** Only when the soonest open, not-yet-applied role closes within 48 hours. `margin: 18px 16px 0`, `border-radius: 14px`, `background: #FDEAE0`, `border: 1px solid rgba(251,88,19,.28)`, `padding: 14px 16px`. Inside: an 8px flame dot + `CLOSING SOON` eyebrow in `--closing`; company name 19px serif; `{role} · {location}` 13.5px slate; `{formatCountdown()} · {formatDateTimeIST()} IST` 13.5px/500 `--closing` tabular; then a full-width 44px navy `Apply now` button, `border-radius: 8px`, 15px/600.
3. **Pinned.** Section header row: `Pinned` 17px serif + `All announcements` navy 13px link. One card, `border-left: 3px solid var(--navy)`, chips row, 17px serif title, 13.5px body, then `{author} · {relative} · {n} comments` 12.5px slate.
4. **Open roles.** Header row with `See all {n}`. Up to two compact role rows (see the role row spec under 2d).
5. **This week.** One card, no gaps between rows, `1px var(--rule)` dividers. Each row: a 44px date column (`MON` 10px/600 uppercase slate over the day number 18px/600 tabular), then title 14px/500 and `{time} · {venue}` 12.5px slate. A deadline row sets the day number and the time in `--closing`.

Empty states are one sentence, no illustration, no exclamation mark: `No open roles right now. New postings appear here and you'll get an email.`

### 2c — Announcements · `/announcements` (new route)

Move the announcements feed off Home into its own route. Home keeps only the pinned card.

- Title row: eyebrow `Slot 1 · 2026`, title `Announcements`, 36px avatar on the right.
- **`Post a submission`** — full-width 44px navy button with a `M12 5v14M5 12h14` plus icon, then helper text: `Goes to the committee for approval before it appears here.` Links to `/announcements/new`.
- **Filter pills**, horizontally scrollable, `gap: 8px`, each `height: 34px`, `padding: 0 14px`, `border-radius: 999px`. Active: navy fill, white, 13px/600. Inactive: white fill, `1px var(--rule)`, ink, 13px/500. Pills: All · Shortlist · PPT · Deadline · Process. Drive them from a `?category=` search param so the page stays a server component.
- Feed on `var(--scroll)`, `padding: 18px 16px 20px`, `gap: 10px`, with `PINNED` / `EARLIER` group eyebrows. Card: chips, 18px serif title, 13.5px/1.55 body, then a `View attachment` navy link and a `{n} comments` slate label on one row, then `{author} · {formatDateTimeIST()} IST` 12px in `--shut`.
- **Your submissions** last, in a `1px dashed var(--rule)` card on `var(--paper)`: title 14px/500 plus `Awaiting review` or `Not approved — {reason}` 12.5px slate. Query already exists in `page.tsx`.

### 2d — Open roles · `/jobs` (new route)

Title eyebrow is `{open} open · {closing} closing`. Filter pills: All · Not applied · Eligible (eligible = `student.total_experience_years >= job.min_experience_years`).

**Role row** — the workhorse. `border-radius: 14px`, `background: var(--surface)`, `border: 1px solid var(--rule)`, and `border-left: 3px solid` coloured by `getDeadlineUrgency()`: `live` → `--live`, `urgent` → `--flame`, `shut` → `--shut` plus `opacity: .6` on the whole row. `padding: 14px 16px`.

Contents: a 40px company logo (`CompanyLogo`, `border-radius: 8px`, `1px var(--rule)`, `var(--paper)` fill, two-letter initials 13px/600 slate as fallback), then company name 17px serif, `{role} · {location} · {n}+ yrs` 12.5px slate, then the countdown 13px/500 tabular — `--closing` when urgent, `--slate` otherwise, always relative-then-absolute: `Closes in 31 hours · Wed 12 Mar, 6:00 PM IST`. `Applied ✓` sits top-right in 12.5px/500 `--live`.

The apply button inside the row is **filled navy when urgent, navy outline otherwise**, 42px, and is omitted entirely once applied or closed. The whole card is also a link to the role.

### 2e — Role detail · `/jobs/[id]`

- Back link: `← {company.name}`, 13px/500 slate, in a 44px-tall tap area.
- 52px logo + role title 24px serif + `{company} · {location}` 13.5px slate.
- Countdown capsule: `padding: 7px 11px`, `border-radius: 8px`, `background: #FDEAE0`, a 7px flame dot, text 12.5px/600 `--closing` tabular. When not urgent, use `var(--paper)` fill and slate text.
- Two eligibility tiles side by side, `border-radius: 10px`, `1px var(--rule)`: `Min. experience` / `You have`. The student's own figure is `--live` when it clears the bar, `--closing` when it does not.
- Description 14px/1.6, capped at 68 characters per line.
- `View JD (PDF)` — 40px navy-outline button.
- **Apply sheet.** Keep the existing `<dialog>` in `apply-dialog.tsx`, restyled as a bottom sheet: `border-radius: 20px 20px 0 0`, `padding: 20px`, `box-shadow: 0 -4px 24px rgba(11,37,69,.2)`, backdrop `rgba(11,37,69,.45)`, a 40px × 4px `var(--rule)` grab handle centred at the top. Title `Apply with which CV?` 19px serif. Then **radio rows, not a `<select>`** — each `padding: 13px 14px`, `border-radius: 10px`; selected gets `2px solid var(--navy)` and `#F5F8FB` fill with a filled 20px navy radio, unselected `1px var(--rule)` with a `1.5px var(--shut)` ring. Row shows the CV label 14.5px/500 and `Uploaded {date}` 12px slate. Footer: 48px navy `Apply with this CV`, then a 44px `Cancel` text row in slate.
- Applied state, deadline-passed state and the eligibility-blocked list are already implemented in `page.tsx` — keep that logic verbatim, restyle only.
- `Withdraw` stays an **underlined text link in `--closing`**, 15px/500. Never a filled red button.

### 2f — Profile · `/profile`

- **Ink header band**, `background: var(--ink)`, `padding: 16px 20px 20px`: 56px navy avatar with a `rgba(255,255,255,.28)` 2px ring, name 21px serif white, `{roll} · {exp} yrs · MBAEx 2026` 12.5px in `rgba(255,255,255,.65)` tabular.
- **Your CVs · {n} of 3** eyebrow, with `Freeze {date}` on the right in `--closing` 11.5px when a freeze date is set.
- CV row: `border-radius: 12px`, `1px var(--rule)`, `padding: 12px 14px`. A 36 × 44 PDF thumb — `border-radius: 5px`, `PDF` 9px/700 bottom-centred; the CV used in the most applications gets `#FDEAE0` fill with a `rgba(251,88,19,.3)` border and `--closing` text, the others `var(--paper)` / `var(--rule)` / slate. Then the label 14.5px/500 and `Uploaded {date} · used in {n} applications` 12px slate. Two 36px icon buttons on the right, `border-radius: 8px`, `1px var(--rule)`: an eye in navy (view) and a bin in `--closing` (delete). Delete keeps the existing `ConfirmSubmitButton` confirmation.
- **Upload panel — this is the one the user specifically called out.** It must read as a button, not a file input. `border-radius: 12px`, `border: 1.5px dashed var(--navy)`, `background: #F5F8FB`, `padding: 18px 14px`, centred column, `gap: 8px`: a 44px navy filled circle holding a white up-arrow (`M12 19V5M6 11l6-6 6 6`), then `Upload a CV` 15px/600 navy, then `PDF, up to 2 MB · {n} slot{s} left` 12px slate. The whole panel is the label for a visually-hidden `<input type="file">`; also accept drop. Keep the client-side type and 2MB checks from `cv-upload-form.tsx`, and show the error below the panel in `--closing` 13px. At three CVs, replace the panel with `You've reached the 3 CV limit. Delete one to upload another.`
- **Set by the committee** — a read-only table card, `border-radius: 12px`, label/value rows at `padding: 11px 14px` split by 1px rules, label slate 13px, value ink 13px/500. Footnote: `Contact a placement rep to correct any of this.`
- **You can edit** — phone and LinkedIn, 44px inputs, `border-radius: 8px`, labels above at 12px slate, then a 44px navy `Save changes` button. Existing `profile-form.tsx` action.
- Sign out and, for admins, an `Open admin` link go at the very bottom of this screen.

### 2g — Calendar · `/calendar`

Drop the 7-column month grid on phone; keep it for the admin/desktop view if you want it.

- Month label as the eyebrow, `Calendar` as the title, prev/next as two 36px outline icon buttons.
- **Week strip**, horizontally scrollable, `gap: 6px`. Each day 46px wide, `padding: 8px 0`, `border-radius: 10px`, centred: weekday 9.5px/600 uppercase, day number 17px/600 tabular, then a 5px dot. Today: `var(--ink)` fill, white text, white dot. A day with a deadline: `#FDEAE0` fill, `rgba(251,88,19,.35)` border, `--closing` text, flame dot. A day with only events: white fill, `1px var(--rule)`, navy dot. Empty days keep the dot slot but leave it transparent so the baseline does not shift.
- Agenda below on `var(--scroll)`, grouped by day with a day eyebrow (in `--closing` when that day holds a deadline). Cards get `border-left: 3px solid` — navy for events, flame for deadlines. Header row: a type chip left, the time right in 12.5px/500 tabular. Then the title 17px serif and `{type} · {company} · {venue}` 12.5px slate. Action links 12.5px/500 navy: `Add to Google Calendar` (keep `googleCalendarUrl()`), `View role`, `Join link`. A deadline card gets a 40px navy `Apply now` button instead of links.

### 2h — My applications · `/applications` (new route)

Reachable from the profile screen and from Home. Eyebrow `{live} live · {offers} offer`.

Card: company name 17px serif, `{role} · {location}` 12.5px slate, status chip top-right. Then a **four-segment progress bar** — Applied → Shortlisted → In process → Offer, each segment `flex: 1`, `height: 4px`, `border-radius: 999px`, `gap: 6px`; reached segments `--live`, unreached `var(--rule)`. Labels under it at 10px, the current step in `--live`, later steps in `--shut`. Then `{cvLabel} · applied {date} · updated {date}` 12.5px slate. `Not selected` cards drop to `opacity: .72` and show no progress bar. `Withdraw` is the underlined `--closing` text link, shown only before the deadline.

### 2i — Sign-in · `/login`

The one centred page. `background: var(--paper)` — remove the `bg-zinc-50 dark:bg-black` currently there; there is no dark mode in this product. Card `border-radius: 20px`, `1px var(--rule)`, `padding: 40px 28px`, centred: IIMC seal at **64px**, 28px of space, `MBAEx` at 26px/700 navy with flame `Ex`, `Placements` at 13px `letter-spacing: .16em` uppercase slate, then `Sign in with your institute Google account to continue.` 14px/1.55 slate capped at 26 characters per line, then a 48px `Continue with Google` button — white fill, `1px var(--rule)`, ink 15px/600, real Google mark on the left. Footnote 11.5px `--shut`: `Only @email.iimcal.ac.in accounts are accepted.` Errors from `searchParams` render in a `#FDEAE0` panel with `--closing` text, never `red-50`/`red-700`.

### 2j — Admin overview · `/admin`

Replace the five-card `zinc` stat grid entirely.

- Eyebrow `Slot 1 · {month} {year}`, title `Overview`.
- **Adoption panel**, `grid-template-columns: 1.35fr 1fr`. Left card: `COHORT ADOPTION` eyebrow with `last 7 days` on the right; then `{active}` at 44px/600 tabular beside `of {total} students active` 15px slate; then a segmented 10px `border-radius: 999px` bar — `--live` active, `--flame` dormant 7–30 days, `var(--rule)` never signed in — with a legend of 9px squares below; then a 1px rule and three sub-stats: `Signed in at least once`, `Uploaded ≥1 CV`, `Applied to ≥1 role`, each `{n} / {total}` at 21px/600 tabular.
- Right column: a **Needs your attention** card in `#FDEAE0` with `rgba(251,88,19,.28)` border — pending approvals, roles closing in 48h, shortlists not yet uploaded, each a label/number row with the number in 15px/600 `--closing`. Below it a white **Slot 1 so far** card — companies, roles posted, applications, offers (offers in `--live`).
- **Not seen in 7+ days** (lifted from 2k): a white panel, header row with the title 17px serif and an `Email all {n}` navy link, then rows split by 1px rules — name 13.5px/500, `{roll} · {n} CVs · {n} applications` 11.5px slate, and the last-seen date right-aligned in 12.5px/500, `--closing` for never/long-dormant.
- **Applications per role** — a horizontal bar list, open roles only. Label column fixed at 170px, 13px; bar `height: 20px`, `border-radius: 3px`, `var(--navy)` fill on a `#ECEFF3` track, widths proportional to the max; count right-aligned in a 36px column, 13px/500 tabular.

No four-big-numbers row across the top. That is what 1b does today and it is the thing to remove.

### 2l — Admin jobs · `/admin/jobs`

Eyebrow `{total} roles · {open} open`; title `Jobs`; a 40px navy `Create a role` button top-right. Filter chips (`border-radius: 6px`, 34px, active `var(--ink)` fill): All · Open · Closing soon · Closed, each with a count. A 220px search field on the right.

Table: `border-radius: 8px`, `1px var(--rule)`, `background: var(--surface)`. Header row `background: var(--paper)`, cells 12px/500 slate, `padding: 11px 16px`, `1px var(--rule)` bottom. Body rows 48px with 1px rules, no zebra striping. Columns: Company · Role · Deadline · Status · Applicants (right) · Actions (right).

The company cell leads with an **8px × 26px `border-radius: 2px` bar** coloured by deadline state — the same vocabulary as the student role row's left rule. Role title in 14px serif/600. An urgent deadline is set in `--closing`. Status is a dot plus word. Applicants is a navy link to the applicants page. Actions: `Applicants | Edit | ···`.

**Delete lives only in that `···` menu**, never as a red button beside Edit. Menu: 186px, `border-radius: 6px`, `1px var(--rule)`, the one shadow, items at `padding: 10px 14px` / 13px — Duplicate role · Reopen applications · Export applicants · 1px rule · `Delete role…` in `--closing`/500. `toggleJobOpen` in `actions.ts` already backs Reopen.

### 2m — Delete a role

Modal over a dimmed page (`rgba(11,37,69,.42)`), 520px, `border-radius: 8px`.

- Title: `Delete "{role}" at {company}?` 21px serif.
- `This cannot be undone. Deleting the role also destroys:` then a `#FDEAE0` panel listing the real cascade counts — applications, recorded offers, calendar entries and linked events, announcements referencing the role. Numbers in 13.5px/600 `--closing`. **Query these live**; do not hard-code.
- **Offer the softer path first:** a bordered row — `Close it instead?` with `Closing hides the role from students and keeps every application and offer on record.` and a 36px navy-outline `Close role` button.
- **Typed confirmation:** `Type {role title} to confirm`, the title rendered in 13px/600 monospace ink. The submit button stays disabled (`#ECEFF3` fill, `--shut` text) until the input matches exactly.
- Footer: `Cancel` as a slate text link, then `Delete role and {n} applications` — the count in the label, so the consequence is unavoidable.

Add the `deleteJob` server action with a `requireAdmin()` check and a server-side re-verification of the typed title.

### 2n — Applicants · `/admin/jobs/[id]/applicants`

Back link `← Jobs`. Title = role, subtitle `{company} · {location} · closes {datetime} IST · {n} applicants`. Two navy-outline buttons top-right: `Upload shortlist (.xlsx)` and `Export as Excel` — both already implemented (`shortlist-upload-form.tsx`, `export/route.ts`).

**Selection bar**, shown when rows are selected: `background: var(--ink)`, `border-radius: 8px`, `padding: 14px 18px`. `{n} selected` in white 13.5px/500, a divider, `Set status to [Shortlisted ⌄]` on a `rgba(255,255,255,.14)` control, a white `Apply to {n}` button, then pushed right a **flame** `Download {n} CVs as .zip` button with a download icon — this surfaces `cvs/route.ts`, which is currently invisible in the UI. Flame is used here as a fill behind white text, which is legitimate; do not set flame as text anywhere.

Table: 44px rows, checkbox column 40px (15px `border-radius: 3px` box, navy when checked), then Name · Roll no. · Exp. (right, tabular) · CV (navy link) · Applied · Status chip. Selected rows tint `#F5F8FB`. Sticky header once the list passes a screen. `bulk-status-form.tsx` already handles the mutation.

### 2o — Moderation queue · `/admin/announcements`

Eyebrow `{n} waiting · oldest {n} days` in `--closing`; title `Announcements`; a navy `Post an announcement` button. Filter chips: Pending · Approved · Rejected with counts.

Pending card: `padding: 18px 20px`, two columns with `gap: 20px`. Left — a `Pending {n} days` chip in deadline-change colours plus `{author} · {roll} · submitted {datetime}` 12px slate; then the title 19px serif, the body 14px/1.6 capped at 68 characters, then `{n} attachment · {filename}` as a navy link. Right, a fixed 230px action column: a `Category` select (the five categories), a `Pin to the top` checkbox, a 40px navy `Approve and publish`, a 40px outline `Edit before publishing`, and `Reject with a reason` as an underlined `--closing` text link opening the existing `reject-dialog.tsx`. Approved and rejected cards use the same card without the action column.

### 2p — Students · `/admin/students` (new route)

Eyebrow `{total} registered · {active} active this week`; title `Students`; `Import from Excel` (outline) and `Add a student` (navy) buttons — `xlsx` is already a dependency.

Filter chips with counts: All · Active · **Dormant** (this one gets a `rgba(251,88,19,.4)` border and `--closing` text) · Never signed in · No CV. Plus a 200px search.

Table, 44px rows: Name · Roll no. · Exp. (right) · CVs (right) · Applications (right) · Last opened · action. `Last opened` is `--live` inside 7 days, `--closing` beyond it or `Never`. The action is `View`, or `Resend invite` for a student who has never signed in. Zero counts render in `--shut`.

### 2q — Forms

All three follow one pattern: a card with a `var(--paper)` header strip (title 19px serif + one line of helper text), a body at `padding: 20px 22px` with `gap: 14px`, and a `var(--paper)` footer strip holding `Cancel` as a slate text link and a 40px navy primary button, right-aligned.

Fields: label above at 12.5px slate with 6px of space, input 40px, `border-radius: 6px`, `1px var(--rule)`; textarea `min-height: 82px`. Focus is a 2px `var(--ink)` outline at 2px offset. Errors sit below the field in 11.5px `--closing` and the border goes `1.5px var(--closing)` — never colour alone, always name what to fix.

Specifics:
- **Create a role** — Company + Role title on one row; Description; Location + Deadline + Min. experience on one row. When the deadline is under 48 hours away, flag it inline: `Under 48 hours away — students get the closing-soon flag immediately.` The JD upload uses the same dashed-navy panel as the CV upload, at `padding: 16px` in a horizontal arrangement. `Open for applications` is a **36 × 20 navy toggle**, not a bare checkbox.
- **Add a company** — Name + Sector on one row; Logo URL with a live 48px preview beside it that falls back to two-letter initials, matching `company-logo.tsx`.
- **Add a calendar event** — Title + Type on one row, Type as a **segmented control** of 40px chips (PPT · Interview · Test · Other, from `EVENT_TYPE_LABELS`); Starts + Ends; Venue + `Link to a role`.

---

## Interactions & behaviour

- **Navigation.** Bottom nav is five `<Link>`s; `usePathname()` sets the active tab. No client router state. Avatar in the header always goes to `/profile`.
- **Apply.** Tap Apply → bottom sheet slides up over a scrim → pick a CV radio → `Apply with this CV`. Button text goes to `Applying…` and disables while `pending`. On success the sheet closes and the role page re-renders in its applied state. Sheet transform `transform: translateY(0)` from `translateY(100%)`, 220ms `cubic-bezier(.32,.72,0,1)`; scrim fades over 180ms. Wrap both in `@media (prefers-reduced-motion: reduce)` and drop to an instant show.
- **Destructive actions.** Withdraw, delete CV, delete comment: underlined `--closing` text link → confirm → `…ing` pending label. Delete a role: the full typed-confirmation modal in 2m. There is no filled red button anywhere in this product.
- **Upload.** Client-side type and size checks before submit (already in `cv-upload-form.tsx`); on selection show the filename in the panel; button reads `Uploading…` while pending; the form resets on success.
- **Filters.** Every filter pill set is a `?category=` / `?status=` search param on a server component, so filtered views are linkable and there is no client state to manage.
- **Countdowns.** `formatCountdown()` is computed on the server and will go stale on a page left open. Either re-render on focus or hydrate a small client component that ticks once a minute — the 48-hour threshold flipping is the case that matters.
- **Hover.** Rows and cards move their background to `var(--surface)` on hover. No lift, no scale, no shadow change.
- **Focus.** Every interactive element keeps a visible 2px `var(--ink)` outline at 2px offset. Real `<button>` and `<a>`, never clickable divs.
- **Responsive.** The student column is 390px and centred above 768px, edge-to-edge below. Admin is fluid from 1024px up; below that, admin tables scroll horizontally inside their rounded container.

## State

Almost none. Everything is server-rendered from Supabase with `useActionState` on the forms that already have it. The only client state in the whole redesign:

- `bottom-nav.tsx` — `usePathname()`.
- `apply-dialog.tsx` — open/closed, selected CV id.
- `cv-upload-form.tsx` — selected file, client-side validation error.
- `announcement-card.tsx` — comments expanded, replying-to id (already implemented).
- The delete-role modal — the typed confirmation string.

## Schema additions required

Two columns, both flagged on the screens that need them. Neither exists today.

1. `students.last_seen_at timestamptz` — written on every authenticated page load (a cheap update in `src/lib/supabase/middleware.ts`, throttled to once an hour per user). Drives every adoption number on 2j and the `Last opened` column on 2p. **Active is defined as: opened the portal at least once in the last 7 days.**
2. `announcements.category text` — one of `ppt`, `shortlist`, `deadline`, `process`, `general`. Drives the chips and the filter pills on 2c and the category select on 2o. Backfill existing rows to `general`.

Optional, for the unread dot on the Notices tab: `students.last_notices_seen_at timestamptz`.

## Assets

- **`assets/logo-iimc.svg`** — the IIM Calcutta seal, supplied by the user, 321 × 311, transparent. Copy to `/public/logo-iimc.svg`. Use untinted at 28px in the student header, 30px on a paper chip in dark bars, 64px on sign-in. Never below 24px, never filtered.
- **MBAEx wordmark** — set in type, not an image: `MBA` in `--navy` + `Ex` in `--flame`, IBM Plex Sans 700, `letter-spacing: -.01em`. This was the user's explicit choice because the MBAEx raster they have has a solid white background. If a transparent SVG turns up later, swapping it in is a one-line change in the header.
- **Icons** — hand-rolled 24×24 stroke paths, listed inline in the bottom-nav table above and readable in the prototype source. There is no icon library; do not add one. All are `fill: none`, `stroke: currentColor`, `stroke-width: 1.9` (2.2 for chevrons and plus signs), round caps and joins.
- **Company logos** — admin-supplied URLs via `CompanyLogo`, falling back to two-letter initials. Unchanged.

## Files in this bundle

- `MBAEx Placement Portal.dc.html` — all 22 screens on one canvas. Open in a browser; zoom out to see everything, and use the id badges to navigate.
- `support.js` — runtime required by the prototype file.
- `assets/logo-iimc.svg` — the seal.

## Files to change in the repo

New: `src/app/(app)/admin/layout.tsx`, `src/components/bottom-nav.tsx`, `src/app/(app)/announcements/page.tsx`, `src/app/(app)/jobs/page.tsx`, `src/app/(app)/applications/page.tsx`, `src/app/(app)/admin/students/page.tsx`, and the delete-role action + modal.

Rewritten: `src/app/(app)/layout.tsx`, `src/components/header.tsx`, `src/app/(app)/page.tsx`, `src/app/login/page.tsx`, `src/app/(app)/profile/page.tsx`, `src/app/(app)/profile/cv-upload-form.tsx`, `src/app/(app)/jobs/[id]/apply-dialog.tsx`, `src/app/(app)/admin/page.tsx`, `src/app/(app)/admin/jobs/page.tsx`, `src/app/(app)/admin/jobs/[id]/applicants/page.tsx`, `src/app/(app)/admin/announcements/page.tsx`, and all three admin forms.

Restyled only, logic untouched: `src/components/job-card.tsx`, `src/components/announcement-card.tsx`, `src/app/(app)/jobs/[id]/page.tsx`, `src/app/(app)/calendar/page.tsx`, `src/app/(app)/profile/profile-form.tsx`, `src/components/confirm-submit-button.tsx`, `src/components/confirm-form-button.tsx`, `src/app/(app)/admin/jobs/open-toggle-button.tsx`.

Also: add the two new colour tokens and the two new Plex weights, delete every `dark:` variant in the codebase (dark mode is explicitly out of scope), and reconcile `DESIGN.md` with the two rules this work overrides — coloured category chips and the uppercase eyebrow.
